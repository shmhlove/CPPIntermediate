/*
* HOME       : ecourse.co.kr
* EMAIL      : smkang @ codenuri.co.kr
* COURSENAME : C++ Intermediate
* MODULE     : main.cpp
* Copyright (C) 2018 CODENURI Inc. All rights reserved.
*/

// main.c /  main.cpp
#include "square.h"
#include <stdio.h> 

int main()
{
	square(3);
	printf("hello");
}
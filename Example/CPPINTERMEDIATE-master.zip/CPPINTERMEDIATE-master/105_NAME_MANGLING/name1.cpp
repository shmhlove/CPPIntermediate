/*
* HOME       : ecourse.co.kr
* EMAIL      : smkang @ codenuri.co.kr
* COURSENAME : C++ Intermediate
* MODULE     : name1.cpp
* Copyright (C) 2018 CODENURI Inc. All rights reserved.
*/

int square(int n)		// squarei()
{
	return n * n;
}

double square(double d)	// squared()
{
	return d * d;
}

int main()
{
	square(3);		// squarei(3)
	square(3.3);	// squared(3.3)
}


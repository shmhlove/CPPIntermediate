/*
* HOME       : ecourse.co.kr
* EMAIL      : smkang @ codenuri.co.kr
* COURSENAME : C++ Intermediate
* MODULE     : square.c
* Copyright (C) 2018 CODENURI Inc. All rights reserved.
*/

// square.c
int square(int n)	
{
	return n * n;
}

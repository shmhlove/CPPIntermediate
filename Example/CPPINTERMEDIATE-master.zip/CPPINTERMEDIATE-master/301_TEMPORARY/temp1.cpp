﻿/*
* HOME       : ecourse.co.kr
* EMAIL      : smkang @ codenuri.co.kr
* COURSENAME : C++ Intermediate
* MODULE     : temp1.cpp
* Copyright (C) 2017 CODENURI Inc. All rights reserved.
*/

int main()
{
	int a = 1, b = 2, c = 3;

	int sum = a + b + c;	// int temp = a + b;
							// int sum  = temp + c;
}


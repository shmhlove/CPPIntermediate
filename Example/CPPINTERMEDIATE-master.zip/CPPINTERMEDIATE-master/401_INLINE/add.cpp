/*
* HOME       : ecourse.co.kr
* EMAIL      : smkang @ codenuri.co.kr
* COURSENAME : C++ Intermediate
* Copyright (C) 2018 CODENURI Inc. All rights reserved.
*/

// add.cpp
int Add1(int a, int b)
{ 
	return a + b; 
}
inline int Add2(int a, int b)
{
	return a + b;
}
/*
* HOME       : ecourse.co.kr
* EMAIL      : smkang @ codenuri.co.kr
* COURSENAME : C++ Intermediate
* Copyright (C) 2018 CODENURI Inc. All rights reserved.
*/

// inline3.cpp
#include "add.h"

int main()
{
	Add1(1, 2); // call (4����Ʈ�����)
	Add2(1, 2); //
}
